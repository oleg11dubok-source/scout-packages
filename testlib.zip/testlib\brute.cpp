#include <iostream>
#include <string>
#include <chrono>
#include <iomanip>
#include <windows.h>

using namespace std;
using namespace std::chrono;

string fmt(long long n) {
    string s = to_string(n);
    string res = "";
    for (int i = 0; i < s.size(); i++) {
        if (i > 0 && (s.size() - i) % 3 == 0) res += " ";
        res += s[i];
    }
    return res;
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    cout << "=== Брутфорсер C++ (без записи в файл) ===\n\n";
    cout << "Введи пароль: ";
    string password;
    getline(cin, password);

    string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
                     "абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
                     "0123456789"
                     "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

    long long total = 1;
    for (int i = 0; i < password.length(); i++) {
        total *= charset.length();
    }

    cout << "Символов в наборе: " << charset.length() << endl;
    cout << "Всего комбинаций: " << fmt(total) << "\n\n";

    // Сравнение скоростей
    double cpu_speed = 1.75e9;
    double igpu_speed = 8.0e9;
    double rtx4090 = 200.0e9;

    cout << "=== Примерное время взлома ===\n";
    cout << "Твой CPU:                 ~ " << (total / cpu_speed / 60) << " минут\n";
    cout << "Твоя AMD Radeon Graphics: ~ " << (total / igpu_speed / 60) << " минут\n";
    cout << "Одна RTX 4090:            ~ " << (total / rtx4090) << " секунд\n\n";

    cout << "Перебор запущен...\n\n";

    auto start = high_resolution_clock::now();
    long long count = 0;

    while (count < total) {
        count++;

        if (count % 10000 == 0) {
            auto now = high_resolution_clock::now();
            double sec = duration_cast<milliseconds>(now - start).count() / 1000.0;
            double kt = (sec > 0) ? count / sec / 1000.0 : 0.0;
            double perc = (total > 0) ? (double)count / total * 100.0 : 0.0;

            string left = "очень долго...";
            if (sec > 0) {
                double rem = (total - count) / (count / sec);
                if (rem > 86400) left = to_string((long long)(rem / 86400)) + " дней";
                else if (rem > 3600) left = to_string((long long)(rem / 3600)) + " ч";
                else if (rem > 60) left = to_string((long long)(rem / 60)) + " мин";
                else left = to_string((long long)rem) + " сек";
            }

            cout << "\rПеребрано: " << fmt(count) << " / " << fmt(total)
                 << " | Скорость: " << fixed << setprecision(1) << kt << " kt/s"
                 << " | " << fixed << setprecision(4) << perc << "%"
                 << " | Ост: " << left << "          " << flush;
        }
    }

    cout << "\n\nПеребор завершён.\n";
    system("pause");
    return 0;
}